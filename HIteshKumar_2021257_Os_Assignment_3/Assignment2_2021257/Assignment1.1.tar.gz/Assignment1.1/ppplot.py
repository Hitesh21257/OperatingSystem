import matplotlib.pyplot as plt
import numpy as np


other=[]
othering=""
counting=[]
rrr=""
RR=[]
fifo=""
FIFO=[]



with open("pplot.txt","r") as f:
    for k in f.readlines():
        for j in k.split():
            if(j=="RR"):
                counter=0
                a=float(k.split()[1])
                counter+=1
                RR.append(a)

            elif(j=="other"):
                counter2=0
                b=float(k.split()[1])
                counter2+=1
                other.append(b)
            elif(j=="FIFO"):
                c=float(k.split()[1])

                counter2+=1
                FIFO.append(c)

f.close()

print("RR")
for i in range(len(RR)):
    print(RR[i])

print("\n")



n=10
x=np.arange(10)

plt.bar(x,other,width=0.30,label="Schdeule_other")

print("OTHER")

for i in range(len(other)):
    print(other[i])

print("\n")


plt.bar(x+0.50,RR,width=0.30,label="Schdeule_rr")




plt.bar(x+0.75,FIFO,width=0.30,label="Schdeule_fifo")

plt.xlabel("Priorities")

print("FIFO")

for i in range(len(FIFO)):
    print(FIFO[i])

print("\n")
plt.title("graph")

plt.ylabel("Time taken")

plt.legend()
plt.show()

