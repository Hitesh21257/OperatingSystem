#include<stdio.h>
#include<time.h>
#include<math.h>
#include<unistd.h>
#include<pthread.h>
double a;
double b;
double c;

void *countA(void *u){
    long finalans=(long) pow(2,32);
    long i=1;
    struct timespec starting;

    struct timespec ending;

    clock_gettime(CLOCK_REALTIME, &starting);

    while(i<=finalans){
        i++;
    }

    clock_gettime(CLOCK_REALTIME,&ending); 

    a = (ending.tv_sec  - starting.tv_sec)  + ((double) (ending.tv_nsec - starting.tv_nsec) / (double) pow(10,9));
    
}

void *countB(void *u){

    struct timespec starting2;
    struct timespec ending2;
    long  finalans2=(long) pow(2,32);
    long j=1;
    clock_gettime(CLOCK_REALTIME, &starting2);
    
    while(j<=finalans2){
        j++;
    }
    clock_gettime(CLOCK_REALTIME,&ending2); 
    double nanodiff2=(double) (ending2.tv_nsec - starting2.tv_nsec);
    b = (ending2.tv_sec  - starting2.tv_sec)  + (nanodiff2 / (double) pow(10,9));
}

void *countC(void *uu){

    struct timespec starting3;
    struct timespec ending3;
    clock_gettime(CLOCK_REALTIME, &starting3);

    long  finalans3=(long) pow(2,32);
    
    long j=1;
    while(j<=finalans3){
        j++;
    }
    clock_gettime(CLOCK_REALTIME,&ending3); 
    double nanodiff3=(double) (ending3.tv_nsec - starting3.tv_nsec);
    c = (ending3.tv_sec  - starting3.tv_sec)  +  (nanodiff3 / ((double) pow(10,9)));


}

int main(){

    pthread_t pid1;
    pthread_t pid2;
    pthread_t pid3;

    FILE *writing;
    writing=fopen("pplot.txt","w");
    fclose(writing);

    for(int kk=0;kk<10;kk++){
        pthread_create(&pid1,NULL,&countA,NULL);
        struct sched_param hitesh;
        hitesh.sched_priority =0;
        int zz = pthread_setschedparam(pid1,SCHED_OTHER,&hitesh);
        
    
        pthread_create(&pid2,NULL,&countB,NULL);
        struct sched_param hitesh2;
        hitesh2.sched_priority = 45+kk+10;
        int yy = pthread_setschedparam(pid2,SCHED_RR,&hitesh2);
        
        pthread_create(&pid3,NULL,&countC,NULL);
        struct sched_param hitesh3;
        hitesh3.sched_priority = 49+kk+10;
        int xx = pthread_setschedparam(pid3,SCHED_FIFO,&hitesh3);

        pthread_join(pid3,NULL);
        pthread_join(pid2,NULL);
        pthread_join(pid1,NULL);
        
        writing=fopen("pplot.txt","a");
        fprintf(writing,"other %f\n",a);
        fprintf(writing,"RR %f\n",b);
        fprintf(writing,"FIFO %f\n",c);

        
        
    }
    
    return 0;
}
